/**
 * Chuyên viên lập trình Min
 * Thực thi logic cho Bộ Tính Toán Hình Học Trực Quan theo yêu cầu của Thầy.
 */

// Chờ cho DOM được tải hoàn tất trước khi thực thi
document.addEventListener('DOMContentLoaded', () => {

    // --- 1. Ánh xạ các thành phần DOM ---
    const shapeSelector = document.getElementById('shape-selector');
    const calculateBtn = document.getElementById('calculate-btn');

    // Các trường nhập liệu
    const inputLength = document.getElementById('input-length');
    const inputWidth = document.getElementById('input-width');
    const inputRadius = document.getElementById('input-radius');
    const inputHeight = document.getElementById('input-height');

    // Các wrapper của trường nhập liệu (để ẩn/hiện)
    const wrappers = {
        length: document.getElementById('input-length-wrapper'),
        width: document.getElementById('input-width-wrapper'),
        radius: document.getElementById('input-radius-wrapper'),
        height: document.getElementById('input-height-wrapper')
    };

    // Khu vực kết quả
    const areaResult = document.querySelector('#result-formula-area span');
    const perimeterResult = document.querySelector('#result-formula-perimeter span');

    // Canvas
    const canvas = document.getElementById('visual-canvas');
    const ctx = canvas.getContext('2d');
    const canvasSize = 400; // Kích thước canvas (width/height)
    const padding = 40; // Vùng đệm xung quanh hình vẽ

    // --- 2. Định nghĩa hàm cập nhật Form ---

    /**
     * Cập nhật hiển thị các trường nhập liệu dựa trên hình được chọn.
     */
    function updateFormVisibility() {
        const selectedShape = shapeSelector.value;

        // Ẩn tất cả các wrapper trước
        Object.values(wrappers).forEach(wrapper => wrapper.classList.add('hidden'));

        // Cập nhật nhãn (label) cho các trường dùng chung
        const lengthLabel = wrappers.length.querySelector('label');
        
        // Hiển thị các trường cần thiết dựa trên lựa chọn
        switch (selectedShape) {
            case 'rectangle':
                lengthLabel.textContent = 'Chiều Dài (d):';
                wrappers.length.classList.remove('hidden');
                wrappers.width.classList.remove('hidden');
                break;
            case 'square':
                lengthLabel.textContent = 'Cạnh (a):';
                wrappers.length.classList.remove('hidden');
                break;
            case 'circle':
                wrappers.radius.classList.remove('hidden');
                break;
            case 'triangle':
                lengthLabel.textContent = 'Cạnh Đáy (b):';
                wrappers.length.classList.remove('hidden');
                wrappers.height.classList.remove('hidden');
                break;
        }
    }

    // --- 3. Định nghĩa hàm Tính toán & Hiển thị Kết quả ---

    /**
     * Thực hiện tính toán và cập nhật kết quả lên giao diện.
     * @returns {object|null} Dữ liệu đã tính toán hoặc null nếu lỗi.
     */
    function calculate() {
        const shape = shapeSelector.value;
        let area = 0;
        let perimeter = 0;
        let data = { shape };

        // Lấy giá trị và chuyển đổi sang số (float)
        const length = parseFloat(inputLength.value) || 0;
        const width = parseFloat(inputWidth.value) || 0;
        const radius = parseFloat(inputRadius.value) || 0;
        const height = parseFloat(inputHeight.value) || 0;

        // Kiểm tra tính hợp lệ của đầu vào
        if (length < 0 || width < 0 || radius < 0 || height < 0) {
            alert("Giá trị nhập vào không thể là số âm. Em sẽ tự động chuyển về 0.");
            // (Mặc dù input min="0" đã cản, nhưng đây là phòng vệ logic)
        }

        switch (shape) {
            case 'rectangle':
                if (length <= 0 || width <= 0) return null; // Yêu cầu giá trị dương
                area = length * width;
                perimeter = 2 * (length + width);
                areaResult.textContent = `S = d * r = ${length} * ${width} = ${area.toFixed(2)}`;
                perimeterResult.textContent = `P = 2 * (d + r) = 2 * (${length} + ${width}) = ${perimeter.toFixed(2)}`;
                data.length = length;
                data.width = width;
                break;
            case 'square':
                if (length <= 0) return null; // Yêu cầu giá trị dương
                area = length * length;
                perimeter = 4 * length;
                areaResult.textContent = `S = a * a = ${length} * ${length} = ${area.toFixed(2)}`;
                perimeterResult.textContent = `P = 4 * a = 4 * ${length} = ${perimeter.toFixed(2)}`;
                data.side = length;
                break;
            case 'circle':
                if (radius <= 0) return null; // Yêu cầu giá trị dương
                area = Math.PI * Math.pow(radius, 2);
                perimeter = 2 * Math.PI * radius;
                areaResult.textContent = `S = π * R² = π * ${radius}² = ${area.toFixed(2)}`;
                perimeterResult.textContent = `P = 2 * π * R = 2 * π * ${radius} = ${perimeter.toFixed(2)}`;
                data.radius = radius;
                break;
            case 'triangle':
                // Giả định là tam giác vuông hoặc tam giác thường với cạnh đáy và chiều cao
                if (length <= 0 || height <= 0) return null; // Yêu cầu giá trị dương
                area = 0.5 * length * height;
                // Chu vi không thể tính chỉ với đáy và chiều cao
                areaResult.textContent = `S = 0.5 * b * h = 0.5 * ${length} * ${height} = ${area.toFixed(2)}`;
                perimeterResult.textContent = `P = (Cần 3 cạnh a, b, c)`;
                data.base = length;
                data.height = height;
                break;
            default:
                return null;
        }
        return data;
    }

    // --- 4. Định nghĩa hàm Vẽ trên Canvas ---

    /**
     * Xóa và vẽ lại hình học trên canvas dựa trên dữ liệu đã tính.
     * @param {object} data - Dữ liệu hình học (shape, dimensions).
     */
    function drawShape(data) {
        // Xóa toàn bộ canvas
        ctx.clearRect(0, 0, canvasSize, canvasSize);

        if (!data) return; // Không vẽ nếu không có dữ liệu

        // Thiết lập style chung cho nét vẽ và chữ
        ctx.strokeStyle = '#005a9c'; // Màu viền
        ctx.fillStyle = 'rgba(0, 123, 255, 0.1)'; // Màu nền
        ctx.lineWidth = 2;
        ctx.font = '14px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const maxDrawSize = canvasSize - (padding * 2); // Kích thước tối đa có thể vẽ

        switch (data.shape) {
            case 'rectangle':
            case 'square':
                let side1 = (data.shape === 'square') ? data.side : data.length;
                let side2 = (data.shape === 'square') ? data.side : data.width;
                
                // Tính toán tỷ lệ
                const maxDim = Math.max(side1, side2);
                const scale = maxDrawSize / maxDim;
                const drawWidth = side2 * scale;
                const drawHeight = side1 * scale; // Thường chiều dài (length) là chiều cao logic
                
                const x = (canvasSize - drawWidth) / 2;
                const y = (canvasSize - drawHeight) / 2;

                // Vẽ hình
                ctx.beginPath();
                ctx.rect(x, y, drawWidth, drawHeight);
                ctx.fill();
                ctx.stroke();

                // Thêm chú thích kích thước
                ctx.fillStyle = '#333'; // Màu chữ
                ctx.fillText(data.shape === 'square' ? data.side : data.width, x + drawWidth / 2, y + drawHeight + 15);
                ctx.fillText(data.shape === 'square' ? data.side : data.length, x - 20, y + drawHeight / 2);
                break;

            case 'circle':
                const drawRadius = maxDrawSize / 2;
                const cX = canvasSize / 2;
                const cY = canvasSize / 2;

                // Vẽ hình tròn
                ctx.beginPath();
                ctx.arc(cX, cY, drawRadius, 0, 2 * Math.PI);
                ctx.fill();
                ctx.stroke();

                // Vẽ đường bán kính
                ctx.beginPath();
                ctx.moveTo(cX, cY);
                ctx.lineTo(cX + drawRadius, cY);
                ctx.strokeStyle = '#d9534f'; // Màu đỏ cho bán kính
                ctx.stroke();

                // Chú thích bán kính
                ctx.fillStyle = '#333';
                ctx.fillText(`R = ${data.radius}`, cX + drawRadius / 2, cY - 10);
                break;

            case 'triangle':
                const base = data.base;
                const height = data.height;

                // Tính toán tỷ lệ
                const maxTriDim = Math.max(base, height);
                const triScale = maxDrawSize / maxTriDim;
                const drawBase = base * triScale;
                const drawHeight = height * triScale;

                const startX = (canvasSize - drawBase) / 2;
                const startY = (canvasSize + drawHeight) / 2;
                const topY = startY - drawHeight;
                const endX = startX + drawBase;

                // Vẽ tam giác (giả định vuông tại startX, startY)
                ctx.beginPath();
                ctx.moveTo(startX, startY); // Góc vuông dưới trái
                ctx.lineTo(endX, startY);   // Góc dưới phải
                ctx.lineTo(startX, topY);  // Đỉnh (nếu là tam giác vuông)
                ctx.closePath();
                ctx.fill();
                ctx.stroke();

                // Vẽ đường chiều cao (nét đứt)
                ctx.beginPath();
                ctx.setLineDash([5, 5]);
                ctx.moveTo(startX, topY);
                ctx.lineTo(startX, startY);
                ctx.strokeStyle = '#5bc0de'; // Màu xanh nhạt
                ctx.stroke();
                ctx.setLineDash([]); // Reset nét

                // Chú thích
                ctx.fillStyle = '#333';
                ctx.fillText(`b = ${data.base}`, startX + drawBase / 2, startY + 15);
                ctx.textAlign = 'left';
                ctx.fillText(`h = ${data.height}`, startX - 30, startY - drawHeight / 2);
                break;
        }
    }

    // --- 5. Gắn các Sự kiện ---

    // Cập nhật form khi chọn hình
    shapeSelector.addEventListener('change', updateFormVisibility);

    // Tính toán và vẽ khi nhấn nút
    calculateBtn.addEventListener('click', () => {
        const calculationData = calculate(); // Tính toán và cập nhật DOM
        drawShape(calculationData);      // Vẽ lên canvas
    });

    // --- 6. Khởi chạy ban đầu ---
    updateFormVisibility(); // Cập nhật form cho giá trị mặc định
    calculateBtn.click(); // Tự động tính toán và vẽ lần đầu
});
